import { Router } from "express";
import { db } from "@workspace/db";
import { specialtiesTable } from "@workspace/db";

const router = Router();

router.get("/specialties", async (req, res) => {
  try {
    const rows = await db.select().from(specialtiesTable);
    res.json(rows);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
