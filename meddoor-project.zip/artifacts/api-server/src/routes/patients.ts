import { Router } from "express";
import { db } from "@workspace/db";
import { patientsTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

router.post("/patients", async (req, res) => {
  try {
    const body = req.body;
    const [patient] = await db.insert(patientsTable).values({
      name: body.name,
      email: body.email,
      phone: body.phone,
      city: body.city,
      dateOfBirth: body.dateOfBirth || null,
      bloodGroup: body.bloodGroup || null,
      medicalHistory: body.medicalHistory || null,
    }).returning();
    res.status(201).json({
      ...patient,
      createdAt: patient.createdAt.toISOString(),
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/patients/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [patient] = await db.select().from(patientsTable).where(eq(patientsTable.id, id));
    if (!patient) return res.status(404).json({ error: "Patient not found" });
    res.json({
      ...patient,
      createdAt: patient.createdAt.toISOString(),
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
