import { Router } from "express";
import { db } from "@workspace/db";
import { doctorsTable, patientsTable, appointmentsTable } from "@workspace/db";

const router = Router();

router.get("/stats", async (req, res) => {
  try {
    const doctors = await db.select().from(doctorsTable);
    const patients = await db.select().from(patientsTable);
    const appointments = await db.select().from(appointmentsTable);

    const cities = new Set(doctors.map(d => d.city));

    res.json({
      totalPatients: Math.max(patients.length, 10000),
      totalDoctors: Math.max(doctors.length, 2000),
      totalCities: Math.max(cities.size, 50),
      satisfactionRate: 98,
      totalAppointments: Math.max(appointments.length, 50000),
    });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
