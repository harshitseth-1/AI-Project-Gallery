import { Router } from "express";
import { db } from "@workspace/db";
import { appointmentsTable, doctorsTable, emergencyRequestsTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

router.get("/appointments", async (req, res) => {
  try {
    const { patientId, doctorId, status } = req.query as Record<string, string>;
    let rows = await db.select().from(appointmentsTable);

    if (patientId) rows = rows.filter(a => a.patientId === parseInt(patientId));
    if (doctorId) rows = rows.filter(a => a.doctorId === parseInt(doctorId));
    if (status) rows = rows.filter(a => a.status === status);

    res.json(rows);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/appointments", async (req, res) => {
  try {
    const body = req.body;
    const [doctor] = await db.select().from(doctorsTable).where(eq(doctorsTable.id, body.doctorId));
    if (!doctor) return res.status(404).json({ error: "Doctor not found" });

    const [appt] = await db.insert(appointmentsTable).values({
      patientId: body.patientId,
      doctorId: body.doctorId,
      doctorName: doctor.name,
      patientName: body.patientName,
      specialty: doctor.specialty,
      date: body.date,
      time: body.time,
      type: body.type,
      status: "pending",
      address: body.address || null,
      notes: body.notes || null,
      fee: doctor.fee,
    }).returning();
    res.status(201).json(appt);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/appointments/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [appt] = await db.select().from(appointmentsTable).where(eq(appointmentsTable.id, id));
    if (!appt) return res.status(404).json({ error: "Appointment not found" });
    res.json(appt);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/appointments/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const body = req.body;
    const updates: Record<string, unknown> = {};
    if (body.status) updates.status = body.status;
    if (body.notes) updates.notes = body.notes;
    const [appt] = await db.update(appointmentsTable).set(updates).where(eq(appointmentsTable.id, id)).returning();
    if (!appt) return res.status(404).json({ error: "Appointment not found" });
    res.json(appt);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/appointments/emergency", async (req, res) => {
  try {
    const body = req.body;
    const [emergency] = await db.insert(emergencyRequestsTable).values({
      patientName: body.patientName,
      phone: body.phone,
      address: body.address,
      description: body.description,
      status: "pending",
      assignedDoctorId: null,
      assignedDoctorName: null,
    }).returning();
    res.status(201).json(emergency);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
