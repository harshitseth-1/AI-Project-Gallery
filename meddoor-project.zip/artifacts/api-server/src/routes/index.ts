import { Router, type IRouter } from "express";
import healthRouter from "./health";
import doctorsRouter from "./doctors";
import specialtiesRouter from "./specialties";
import appointmentsRouter from "./appointments";
import patientsRouter from "./patients";
import reviewsRouter from "./reviews";
import statsRouter from "./stats";
import availabilityRouter from "./availability";

const router: IRouter = Router();

router.use(healthRouter);
router.use(statsRouter);
router.use(specialtiesRouter);
router.use(doctorsRouter);
router.use(availabilityRouter);
router.use(appointmentsRouter);
router.use(patientsRouter);
router.use(reviewsRouter);

export default router;
