import { Router } from "express";
import { db } from "@workspace/db";
import { reviewsTable, doctorsTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

router.get("/reviews", async (req, res) => {
  try {
    const { doctorId } = req.query as Record<string, string>;
    if (!doctorId) return res.status(400).json({ error: "doctorId is required" });
    const rows = await db.select().from(reviewsTable).where(eq(reviewsTable.doctorId, parseInt(doctorId)));
    res.json(rows.map(r => ({ ...r, createdAt: r.createdAt.toISOString() })));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/reviews", async (req, res) => {
  try {
    const body = req.body;
    const [review] = await db.insert(reviewsTable).values({
      doctorId: body.doctorId,
      patientName: body.patientName,
      rating: body.rating,
      comment: body.comment,
      isFeatured: false,
    }).returning();

    // Update doctor rating
    const allReviews = await db.select().from(reviewsTable).where(eq(reviewsTable.doctorId, body.doctorId));
    const avgRating = allReviews.reduce((sum, r) => sum + r.rating, 0) / allReviews.length;
    await db.update(doctorsTable)
      .set({ rating: Math.round(avgRating * 10) / 10, reviewCount: allReviews.length })
      .where(eq(doctorsTable.id, body.doctorId));

    res.status(201).json({ ...review, createdAt: review.createdAt.toISOString() });
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/reviews/featured", async (req, res) => {
  try {
    const rows = await db.select().from(reviewsTable).where(eq(reviewsTable.isFeatured, true));
    res.json(rows.map(r => ({ ...r, createdAt: r.createdAt.toISOString() })));
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
