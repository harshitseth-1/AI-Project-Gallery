import { Router } from "express";
import { db } from "@workspace/db";
import { doctorsTable } from "@workspace/db";
import { eq, ilike, gte } from "drizzle-orm";

const router = Router();

router.get("/doctors", async (req, res) => {
  try {
    const { specialty, name, minRating, available, city } = req.query as Record<string, string>;
    let query = db.select().from(doctorsTable);

    const conditions: ReturnType<typeof eq>[] = [];
    if (specialty) conditions.push(eq(doctorsTable.specialty, specialty));
    if (city) conditions.push(eq(doctorsTable.city, city));
    if (available === "true") conditions.push(eq(doctorsTable.isAvailable, true));

    let rows = await db.select().from(doctorsTable);

    if (specialty) rows = rows.filter(d => d.specialty.toLowerCase() === specialty.toLowerCase());
    if (name) rows = rows.filter(d => d.name.toLowerCase().includes(name.toLowerCase()));
    if (minRating) rows = rows.filter(d => d.rating >= parseFloat(minRating));
    if (available === "true") rows = rows.filter(d => d.isAvailable);
    if (city) rows = rows.filter(d => d.city.toLowerCase() === city.toLowerCase());

    res.json(rows);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/doctors", async (req, res) => {
  try {
    const body = req.body;
    const [doctor] = await db.insert(doctorsTable).values({
      name: body.name,
      specialty: body.specialty,
      specialtyId: body.specialtyId,
      photoUrl: body.photoUrl || null,
      experience: body.experience,
      city: body.city,
      fee: body.fee,
      bio: body.bio || null,
      languages: body.languages || [],
      qualifications: body.qualifications || [],
      isAvailable: true,
      isVerified: false,
    }).returning();
    res.status(201).json(doctor);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/doctors/featured", async (req, res) => {
  try {
    const rows = await db.select().from(doctorsTable);
    const featured = rows
      .filter(d => d.isVerified)
      .sort((a, b) => b.rating - a.rating)
      .slice(0, 6);
    res.json(featured);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/doctors/:id", async (req, res) => {
  try {
    const id = parseInt(req.params.id);
    const [doctor] = await db.select().from(doctorsTable).where(eq(doctorsTable.id, id));
    if (!doctor) return res.status(404).json({ error: "Doctor not found" });
    res.json(doctor);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
