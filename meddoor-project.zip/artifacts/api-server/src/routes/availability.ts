import { Router } from "express";
import { db } from "@workspace/db";
import { availabilitySlotsTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

router.get("/doctors/:id/availability", async (req, res) => {
  try {
    const doctorId = parseInt(req.params.id);
    const rows = await db.select().from(availabilitySlotsTable).where(eq(availabilitySlotsTable.doctorId, doctorId));
    res.json(rows);
  } catch (err) {
    req.log.error(err);
    res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
