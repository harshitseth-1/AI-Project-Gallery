import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Stethoscope, Activity, User, PhoneCall } from "lucide-react";
import { cn } from "@/lib/utils";

export default function Navbar() {
  const [location] = useLocation();

  const navItems = [
    { label: "Home", href: "/" },
    { label: "Find Doctors", href: "/find-doctors" },
    { label: "How it Works", href: "/how-it-works" },
    { label: "About", href: "/about" },
    { label: "Contact", href: "/contact" },
  ];

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60 shadow-sm">
      <div className="container mx-auto flex h-16 items-center justify-between px-4 md:px-6">
        <Link href="/" className="flex items-center gap-2 mr-6 hover:opacity-90 transition-opacity">
          <div className="bg-primary p-1.5 rounded-lg">
            <Activity className="h-5 w-5 text-primary-foreground" />
          </div>
          <span className="text-xl font-bold tracking-tight text-foreground">MedDoor</span>
        </Link>

        <nav className="hidden md:flex items-center gap-6">
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "text-sm font-medium transition-colors hover:text-primary",
                location === item.href ? "text-primary" : "text-muted-foreground"
              )}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        <div className="flex items-center gap-4">
          <Button variant="ghost" className="hidden sm:flex" asChild>
            <Link href="/appointments">
              <User className="mr-2 h-4 w-4" />
              My Appointments
            </Link>
          </Button>
          <Button variant="destructive" className="font-semibold" asChild>
            <Link href="/emergency">
              <PhoneCall className="mr-2 h-4 w-4 animate-pulse" />
              Emergency
            </Link>
          </Button>
          <Button asChild className="hidden sm:inline-flex">
            <Link href="/find-doctors">
              <Stethoscope className="mr-2 h-4 w-4" />
              Book Doctor
            </Link>
          </Button>
        </div>
      </div>
    </header>
  );
}
