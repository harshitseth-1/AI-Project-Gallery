import { Link } from "wouter";
import { Doctor } from "@workspace/api-client-react";
import { Card, CardContent, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Star, MapPin, Briefcase, IndianRupee } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

interface DoctorCardProps {
  doctor: Doctor;
}

export function DoctorCard({ doctor }: DoctorCardProps) {
  return (
    <Card className="flex flex-col h-full overflow-hidden hover:shadow-lg transition-all border-slate-200 hover:border-primary/30">
      <CardContent className="p-6 flex-grow">
        <div className="flex justify-between items-start mb-4">
          <Avatar className="h-16 w-16 border-2 border-slate-100 shadow-sm">
            <AvatarImage src={doctor.photoUrl || undefined} alt={doctor.name} />
            <AvatarFallback className="bg-primary/10 text-primary font-bold">
              {doctor.name.split(" ").map((n) => n[0]).join("").substring(0, 2)}
            </AvatarFallback>
          </Avatar>
          <Badge variant={doctor.isAvailable ? "default" : "secondary"} className={doctor.isAvailable ? "bg-emerald-500 hover:bg-emerald-600" : ""}>
            {doctor.isAvailable ? "Available Today" : "Next Available Tomm"}
          </Badge>
        </div>
        
        <div className="mb-2">
          <h3 className="text-lg font-bold text-slate-900 line-clamp-1">{doctor.name}</h3>
          <p className="text-sm font-medium text-primary">{doctor.specialty}</p>
        </div>
        
        <div className="flex items-center gap-2 mb-4">
          <div className="flex items-center text-amber-500">
            <Star className="h-4 w-4 fill-current" />
            <span className="ml-1 text-sm font-bold">{doctor.rating.toFixed(1)}</span>
          </div>
          <span className="text-xs text-slate-500">({doctor.reviewCount} reviews)</span>
        </div>
        
        <div className="space-y-2 text-sm text-slate-600">
          <div className="flex items-center gap-2">
            <Briefcase className="h-4 w-4 text-slate-400 shrink-0" />
            <span>{doctor.experience} Years Experience</span>
          </div>
          <div className="flex items-center gap-2">
            <MapPin className="h-4 w-4 text-slate-400 shrink-0" />
            <span className="line-clamp-1">{doctor.city}</span>
          </div>
          <div className="flex items-center gap-2 font-medium text-slate-900">
            <IndianRupee className="h-4 w-4 text-slate-400 shrink-0" />
            <span>{doctor.fee} Consultation Fee</span>
          </div>
        </div>
      </CardContent>
      <CardFooter className="p-4 pt-0 border-t bg-slate-50 mt-auto">
        <div className="flex w-full gap-2 mt-4">
          <Button variant="outline" className="w-1/2" asChild>
            <Link href={`/doctors/${doctor.id}`}>View Profile</Link>
          </Button>
          <Button className="w-1/2 shadow-sm" disabled={!doctor.isAvailable} asChild>
            <Link href={`/book?doctorId=${doctor.id}`}>Book Now</Link>
          </Button>
        </div>
      </CardFooter>
    </Card>
  );
}
