import { Search, CalendarCheck, Home, Activity, CheckCircle2 } from "lucide-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";

export default function HowItWorks() {
  const steps = [
    {
      icon: Search,
      title: "Find Your Specialist",
      desc: "Browse our network of verified doctors by specialty, location, or symptoms. Read authentic reviews from other patients."
    },
    {
      icon: CalendarCheck,
      title: "Book a Time",
      desc: "Choose between a home visit or video consultation. Select a time slot that works perfectly with your schedule."
    },
    {
      icon: Home,
      title: "Receive Care",
      desc: "The doctor arrives at your doorstep or connects via secure video. Experience dedicated, unhurried medical attention."
    },
    {
      icon: Activity,
      title: "Follow Up",
      desc: "Access your digital prescriptions instantly. Your doctor will check in on your recovery within 48 hours."
    }
  ];

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-white">
      <div className="bg-primary/5 py-16 md:py-24 border-b border-primary/10">
        <div className="container mx-auto px-4 max-w-3xl text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-slate-900 mb-6 tracking-tight">How MedDoor Works</h1>
          <p className="text-xl text-slate-600">
            Skip the waiting room. Premium healthcare delivered directly to you in four simple steps.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-20 max-w-5xl">
        <div className="relative">
          {/* Connecting line for desktop */}
          <div className="hidden md:block absolute top-1/2 left-0 w-full h-0.5 bg-slate-100 -translate-y-1/2 z-0" />
          
          <div className="grid md:grid-cols-4 gap-12 relative z-10">
            {steps.map((step, index) => {
              const Icon = step.icon;
              return (
                <div key={index} className="flex flex-col items-center text-center group">
                  <div className="w-20 h-20 bg-white border-4 border-slate-50 rounded-2xl shadow-sm flex items-center justify-center mb-6 group-hover:border-primary/20 group-hover:scale-110 transition-all duration-300 relative">
                    <Icon className="w-8 h-8 text-primary" />
                    <div className="absolute -top-3 -right-3 w-8 h-8 bg-slate-900 text-white rounded-full flex items-center justify-center font-bold text-sm shadow-md">
                      {index + 1}
                    </div>
                  </div>
                  <h3 className="text-xl font-bold text-slate-900 mb-3">{step.title}</h3>
                  <p className="text-slate-600 text-sm leading-relaxed">{step.desc}</p>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      <div className="bg-slate-900 text-white py-20 mt-10">
        <div className="container mx-auto px-4 max-w-4xl text-center">
          <h2 className="text-3xl font-bold mb-8">What makes us different?</h2>
          <div className="grid sm:grid-cols-2 gap-6 text-left mb-12">
            {[
              "100% Background-checked & verified medical professionals",
              "Transparent pricing upfront — no hidden fees",
              "Average arrival time of 45 minutes for home visits",
              "Secure, HIPAA-compliant platform for all your data",
              "Dedicated 24/7 care coordination team",
              "Digital prescriptions valid at all major pharmacies"
            ].map((feature, i) => (
              <div key={i} className="flex items-start gap-3">
                <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                <span className="text-slate-300">{feature}</span>
              </div>
            ))}
          </div>
          <Button size="lg" className="bg-primary hover:bg-primary/90 text-primary-foreground px-8" asChild>
            <Link href="/find-doctors">Find a Doctor Now</Link>
          </Button>
        </div>
      </div>
    </div>
  );
}
