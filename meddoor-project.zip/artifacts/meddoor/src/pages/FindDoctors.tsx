import { useState } from "wouter";
import { Link } from "wouter";
import { useListDoctors, useListSpecialties } from "@workspace/api-client-react";
import { DoctorCard } from "@/components/DoctorCard";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { Search, Filter, X } from "lucide-react";
import { useState as useReactState } from "react";
import { useDebounce } from "@/hooks/use-debounce";

// Custom hook for debouncing since it's not provided in the workspace
function useLocalDebounce<T>(value: T, delay: number): T {
  const [debouncedValue, setDebouncedValue] = useReactState<T>(value);
  useReactState(() => {
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);
    return () => {
      clearTimeout(handler);
    };
  }, [value, delay]);
  return debouncedValue;
}


export default function FindDoctors() {
  const [search, setSearch] = useReactState("");
  const debouncedSearch = useLocalDebounce(search, 500);
  const [specialty, setSpecialty] = useReactState<string>("");
  const [city, setCity] = useReactState<string>("");
  const [availableOnly, setAvailableOnly] = useReactState(false);

  const { data: doctors, isLoading } = useListDoctors({
    name: debouncedSearch || undefined,
    specialty: specialty || undefined,
    city: city || undefined,
    available: availableOnly || undefined,
  });

  const { data: specialties } = useListSpecialties();

  const cities = ["San Francisco", "New York", "Los Angeles", "Chicago", "Miami"]; // Mock cities

  return (
    <div className="container mx-auto px-4 py-8 max-w-7xl">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-900 mb-2">Find Your Doctor</h1>
        <p className="text-slate-600">Browse through our network of top-rated specialists and book an appointment instantly.</p>
      </div>

      <div className="flex flex-col lg:flex-row gap-8">
        {/* Filters Sidebar */}
        <div className="w-full lg:w-64 shrink-0 space-y-6">
          <div className="bg-slate-50 p-5 rounded-xl border">
            <div className="flex items-center gap-2 mb-4 font-semibold text-slate-900 pb-2 border-b">
              <Filter className="w-4 h-4" />
              <span>Filters</span>
              {(search || specialty || city || availableOnly) && (
                <Button 
                  variant="ghost" 
                  size="sm" 
                  className="ml-auto h-8 px-2 text-xs text-muted-foreground hover:text-destructive"
                  onClick={() => {
                    setSearch("");
                    setSpecialty("");
                    setCity("");
                    setAvailableOnly(false);
                  }}
                >
                  Clear All
                </Button>
              )}
            </div>

            <div className="space-y-5">
              <div className="space-y-2">
                <Label className="text-sm font-medium">Search Name</Label>
                <div className="relative">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-400" />
                  <Input 
                    placeholder="Doctor name..." 
                    className="pl-9 bg-white"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                  />
                  {search && (
                    <button 
                      onClick={() => setSearch("")}
                      className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-600"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  )}
                </div>
              </div>

              <div className="space-y-2">
                <Label className="text-sm font-medium">Specialty</Label>
                <Select value={specialty} onValueChange={setSpecialty}>
                  <SelectTrigger className="bg-white">
                    <SelectValue placeholder="All Specialties" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Specialties</SelectItem>
                    {specialties?.map((s) => (
                      <SelectItem key={s.id} value={s.id.toString()}>{s.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label className="text-sm font-medium">City</Label>
                <Select value={city} onValueChange={setCity}>
                  <SelectTrigger className="bg-white">
                    <SelectValue placeholder="All Cities" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Cities</SelectItem>
                    {cities.map((c) => (
                      <SelectItem key={c} value={c}>{c}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center space-x-2 pt-2">
                <Checkbox 
                  id="available" 
                  checked={availableOnly}
                  onCheckedChange={(c) => setAvailableOnly(!!c)}
                />
                <label
                  htmlFor="available"
                  className="text-sm font-medium leading-none peer-disabled:cursor-not-allowed peer-disabled:opacity-70"
                >
                  Available Today Only
                </label>
              </div>
            </div>
          </div>
        </div>

        {/* Results */}
        <div className="flex-1">
          <div className="mb-4 text-sm text-slate-500 font-medium">
            {isLoading ? (
              <Skeleton className="h-5 w-32" />
            ) : (
              <span>Showing {doctors?.length || 0} doctors</span>
            )}
          </div>

          {isLoading ? (
            <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-6">
              {Array(6).fill(0).map((_, i) => (
                <div key={i} className="flex flex-col h-[320px]">
                  <Skeleton className="h-full w-full rounded-xl" />
                </div>
              ))}
            </div>
          ) : doctors && doctors.length > 0 ? (
            <div className="grid sm:grid-cols-2 xl:grid-cols-3 gap-6">
              {doctors.map((doctor) => (
                <DoctorCard key={doctor.id} doctor={doctor} />
              ))}
            </div>
          ) : (
            <div className="bg-slate-50 rounded-xl p-12 text-center border border-dashed flex flex-col items-center">
              <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mb-4 text-slate-400">
                <Search className="w-8 h-8" />
              </div>
              <h3 className="text-lg font-bold text-slate-900 mb-2">No doctors found</h3>
              <p className="text-slate-500 max-w-sm mb-6">
                We couldn't find any doctors matching your current filters. Try adjusting your search criteria.
              </p>
              <Button variant="outline" onClick={() => {
                setSearch("");
                setSpecialty("");
                setCity("");
                setAvailableOnly(false);
              }}>
                Clear Filters
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
