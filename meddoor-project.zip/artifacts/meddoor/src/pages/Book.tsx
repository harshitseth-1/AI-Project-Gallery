import { useState } from "react";
import { useLocation, useSearch } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { 
  useListDoctors, 
  useGetDoctor,
  useGetDoctorAvailability,
  useCreateAppointment,
  AppointmentInputType
} from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from "@/components/ui/card";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { useToast } from "@/hooks/use-toast";
import { Loader2, Home, Video, Calendar, Clock, User, FileText, CheckCircle2 } from "lucide-react";
import { format } from "date-fns";

const bookFormSchema = z.object({
  patientName: z.string().min(2, "Name is required"),
  type: z.enum([AppointmentInputType.home_visit, AppointmentInputType.video_consultation]),
  doctorId: z.coerce.number().min(1, "Please select a doctor"),
  date: z.string().min(1, "Please select a date"),
  time: z.string().min(1, "Please select a time"),
  address: z.string().optional(),
  notes: z.string().optional()
}).superRefine((data, ctx) => {
  if (data.type === AppointmentInputType.home_visit && (!data.address || data.address.trim().length === 0)) {
    ctx.addIssue({
      code: z.ZodIssueCode.custom,
      message: "Address is required for home visits",
      path: ["address"]
    });
  }
});

type BookFormValues = z.infer<typeof bookFormSchema>;

export default function Book() {
  const [_, setLocation] = useLocation();
  const searchString = useSearch();
  const searchParams = new URLSearchParams(searchString);
  const initialDoctorId = searchParams.get("doctorId");
  const initialType = searchParams.get("type") as AppointmentInputType | null;
  const initialDate = searchParams.get("date");
  
  const { toast } = useToast();
  const [isSuccess, setIsSuccess] = useState(false);

  const { data: doctors, isLoading: loadingDoctors } = useListDoctors({ available: true });
  
  const form = useForm<BookFormValues>({
    resolver: zodResolver(bookFormSchema),
    defaultValues: {
      patientName: "",
      type: initialType && Object.values(AppointmentInputType).includes(initialType) ? initialType : AppointmentInputType.video_consultation,
      doctorId: initialDoctorId ? parseInt(initialDoctorId) : undefined,
      date: initialDate || "",
      time: "",
      address: "",
      notes: ""
    }
  });

  const selectedDoctorId = form.watch("doctorId");
  const selectedType = form.watch("type");

  const { data: slots, isLoading: loadingSlots } = useGetDoctorAvailability(
    selectedDoctorId || 0,
    { query: { enabled: !!selectedDoctorId, queryKey: ["availability", selectedDoctorId] } }
  );

  const { data: selectedDoctor } = useGetDoctor(
    selectedDoctorId || 0,
    { query: { enabled: !!selectedDoctorId, queryKey: ["doctor", selectedDoctorId] } }
  );

  const createAppointment = useCreateAppointment();

  // Group slots by date
  const availableSlots = slots?.filter(s => !s.isBooked) || [];
  const uniqueDates = Array.from(new Set(availableSlots.map(s => s.date)));
  
  const selectedDate = form.watch("date");
  const timeSlotsForDate = availableSlots.filter(s => s.date === selectedDate);

  async function onSubmit(data: BookFormValues) {
    try {
      await createAppointment.mutateAsync({
        data: {
          patientId: 1, // Mock authenticated patient ID
          doctorId: data.doctorId,
          patientName: data.patientName,
          type: data.type,
          date: data.date,
          time: data.time,
          address: data.type === AppointmentInputType.home_visit ? data.address : undefined,
          notes: data.notes
        }
      });
      
      setIsSuccess(true);
      window.scrollTo(0, 0);
    } catch (error) {
      toast({
        title: "Booking Failed",
        description: "There was an error booking your appointment. Please try again.",
        variant: "destructive"
      });
    }
  }

  if (isSuccess) {
    return (
      <div className="container mx-auto px-4 py-20 max-w-2xl text-center">
        <div className="bg-white p-12 rounded-3xl shadow-xl border border-slate-100 flex flex-col items-center">
          <div className="w-24 h-24 bg-emerald-100 rounded-full flex items-center justify-center mb-6">
            <CheckCircle2 className="w-12 h-12 text-emerald-600" />
          </div>
          <h1 className="text-3xl font-bold text-slate-900 mb-4">Booking Confirmed!</h1>
          <p className="text-lg text-slate-600 mb-8 max-w-md">
            Your appointment has been successfully scheduled. You'll receive a confirmation SMS shortly.
          </p>
          <div className="flex gap-4">
            <Button variant="outline" onClick={() => setLocation("/appointments")}>View Appointments</Button>
            <Button onClick={() => setLocation("/")}>Return Home</Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container mx-auto px-4 py-12 max-w-3xl">
      <div className="mb-8 text-center">
        <h1 className="text-3xl font-bold text-slate-900 mb-2">Book an Appointment</h1>
        <p className="text-slate-600">Schedule a visit with our verified healthcare professionals.</p>
      </div>

      <Card className="border-slate-200 shadow-lg">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)}>
            <CardContent className="p-6 sm:p-8 space-y-8">
              {/* Type Selection */}
              <div className="space-y-4">
                <h3 className="text-lg font-semibold text-slate-900 flex items-center gap-2">
                  <span className="bg-primary/10 text-primary w-6 h-6 rounded-full flex items-center justify-center text-sm">1</span>
                  Consultation Type
                </h3>
                <FormField
                  control={form.control}
                  name="type"
                  render={({ field }) => (
                    <FormItem>
                      <FormControl>
                        <RadioGroup
                          onValueChange={field.onChange}
                          defaultValue={field.value}
                          className="grid sm:grid-cols-2 gap-4"
                        >
                          <FormItem>
                            <FormControl>
                              <RadioGroupItem value={AppointmentInputType.video_consultation} className="peer sr-only" />
                            </FormControl>
                            <FormLabel className="flex flex-col items-center justify-between rounded-xl border-2 border-slate-200 bg-white p-4 hover:bg-slate-50 peer-data-[state=checked]:border-primary peer-data-[state=checked]:bg-primary/5 cursor-pointer transition-all">
                              <Video className="mb-3 h-8 w-8 text-slate-600 peer-data-[state=checked]:text-primary" />
                              <span className="font-semibold text-slate-900">Video Consult</span>
                              <span className="text-xs text-slate-500 mt-1">Connect online instantly</span>
                            </FormLabel>
                          </FormItem>
                          <FormItem>
                            <FormControl>
                              <RadioGroupItem value={AppointmentInputType.home_visit} className="peer sr-only" />
                            </FormControl>
                            <FormLabel className="flex flex-col items-center justify-between rounded-xl border-2 border-slate-200 bg-white p-4 hover:bg-slate-50 peer-data-[state=checked]:border-primary peer-data-[state=checked]:bg-primary/5 cursor-pointer transition-all">
                              <Home className="mb-3 h-8 w-8 text-slate-600 peer-data-[state=checked]:text-primary" />
                              <span className="font-semibold text-slate-900">Home Visit</span>
                              <span className="text-xs text-slate-500 mt-1">Doctor at your doorstep</span>
                            </FormLabel>
                          </FormItem>
                        </RadioGroup>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="h-px bg-slate-100" />

              {/* Doctor & Patient Details */}
              <div className="space-y-6">
                <h3 className="text-lg font-semibold text-slate-900 flex items-center gap-2">
                  <span className="bg-primary/10 text-primary w-6 h-6 rounded-full flex items-center justify-center text-sm">2</span>
                  Details
                </h3>
                
                <div className="grid sm:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="patientName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Patient Name</FormLabel>
                        <FormControl>
                          <div className="relative">
                            <User className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                            <Input placeholder="Full Name" className="pl-10" {...field} />
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="doctorId"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Select Doctor</FormLabel>
                        <Select 
                          onValueChange={(val) => {
                            field.onChange(val);
                            form.setValue("date", "");
                            form.setValue("time", "");
                          }} 
                          defaultValue={field.value?.toString()}
                          disabled={loadingDoctors}
                        >
                          <FormControl>
                            <SelectTrigger>
                              <SelectValue placeholder="Choose a doctor" />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {doctors?.map(doc => (
                              <SelectItem key={doc.id} value={doc.id.toString()}>
                                {doc.name} - {doc.specialty}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                {selectedType === AppointmentInputType.home_visit && (
                  <FormField
                    control={form.control}
                    name="address"
                    render={({ field }) => (
                      <FormItem className="animate-in fade-in slide-in-from-top-2">
                        <FormLabel>Home Address</FormLabel>
                        <FormControl>
                          <Textarea 
                            placeholder="Complete address with landmark..." 
                            className="resize-none"
                            {...field} 
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                )}
              </div>

              <div className="h-px bg-slate-100" />

              {/* Date & Time */}
              <div className="space-y-6">
                <h3 className="text-lg font-semibold text-slate-900 flex items-center gap-2">
                  <span className="bg-primary/10 text-primary w-6 h-6 rounded-full flex items-center justify-center text-sm">3</span>
                  Schedule
                </h3>

                {!selectedDoctorId ? (
                  <div className="bg-slate-50 p-4 rounded-lg text-center text-sm text-slate-500 border border-slate-100">
                    Please select a doctor to view their availability.
                  </div>
                ) : loadingSlots ? (
                  <div className="flex items-center justify-center p-4">
                    <Loader2 className="h-6 w-6 animate-spin text-primary" />
                  </div>
                ) : uniqueDates.length === 0 ? (
                  <div className="bg-destructive/5 text-destructive p-4 rounded-lg text-sm border border-destructive/20">
                    This doctor has no available slots at the moment. Please select another doctor.
                  </div>
                ) : (
                  <div className="grid sm:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="date"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Date</FormLabel>
                          <Select 
                            onValueChange={(val) => {
                              field.onChange(val);
                              form.setValue("time", "");
                            }} 
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <div className="flex items-center gap-2">
                                  <Calendar className="h-4 w-4 text-slate-400" />
                                  <SelectValue placeholder="Select date" />
                                </div>
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {uniqueDates.map(date => (
                                <SelectItem key={date} value={date}>
                                  {format(new Date(date), 'EEEE, MMMM d')}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="time"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Time</FormLabel>
                          <Select 
                            onValueChange={field.onChange} 
                            defaultValue={field.value}
                            disabled={!selectedDate}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <div className="flex items-center gap-2">
                                  <Clock className="h-4 w-4 text-slate-400" />
                                  <SelectValue placeholder="Select time" />
                                </div>
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {timeSlotsForDate.map(slot => (
                                <SelectItem key={slot.id} value={slot.startTime}>
                                  {slot.startTime} - {slot.endTime}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                )}

                <FormField
                  control={form.control}
                  name="notes"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Symptoms / Notes (Optional)</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <FileText className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                          <Textarea 
                            placeholder="Briefly describe your symptoms or reason for visit..." 
                            className="pl-10 resize-none"
                            {...field} 
                          />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

            </CardContent>

            <CardFooter className="bg-slate-50 border-t p-6 sm:p-8 flex-col sm:flex-row items-center justify-between gap-4">
              <div className="text-slate-600">
                {selectedDoctor && (
                  <p className="text-sm">Consultation Fee: <span className="font-bold text-slate-900 text-lg ml-1">₹{selectedDoctor.fee}</span></p>
                )}
              </div>
              <Button 
                type="submit" 
                size="lg" 
                className="w-full sm:w-auto px-8"
                disabled={createAppointment.isPending}
              >
                {createAppointment.isPending ? (
                  <>
                    <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                    Confirming...
                  </>
                ) : (
                  "Confirm Booking"
                )}
              </Button>
            </CardFooter>
          </form>
        </Form>
      </Card>
    </div>
  );
}
