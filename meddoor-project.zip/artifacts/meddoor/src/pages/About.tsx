import { Activity, Shield, Clock, Heart, Users, Map } from "lucide-react";

export default function About() {
  return (
    <div className="bg-white min-h-[calc(100vh-4rem)]">
      {/* Hero */}
      <section className="bg-slate-50 py-20 border-b">
        <div className="container mx-auto px-4 max-w-4xl text-center">
          <div className="inline-flex items-center justify-center p-3 bg-primary/10 rounded-2xl mb-6">
            <Activity className="h-8 w-8 text-primary" />
          </div>
          <h1 className="text-4xl md:text-5xl font-bold text-slate-900 mb-6 tracking-tight">Healthcare that comes to you.</h1>
          <p className="text-xl text-slate-600 leading-relaxed">
            MedDoor was founded on a simple belief: accessing quality healthcare shouldn't require sitting in a waiting room when you're feeling your worst.
          </p>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-20">
        <div className="container mx-auto px-4 max-w-5xl">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-slate-900 mb-4">Our Mission</h2>
              <p className="text-lg text-slate-600 leading-relaxed mb-6">
                To build the world's most accessible, reliable, and human-centric healthcare delivery network. We bridge the gap between top-tier medical professionals and patients who need care in the comfort of their own homes.
              </p>
              <div className="flex gap-6 mt-8">
                <div className="space-y-2">
                  <h4 className="text-3xl font-bold text-primary">2M+</h4>
                  <p className="text-sm font-medium text-slate-500 uppercase">Consultations</p>
                </div>
                <div className="space-y-2">
                  <h4 className="text-3xl font-bold text-primary">5k+</h4>
                  <p className="text-sm font-medium text-slate-500 uppercase">Doctors</p>
                </div>
              </div>
            </div>
            <div className="bg-slate-100 rounded-3xl p-8 relative overflow-hidden h-[400px]">
              <img 
                src="https://images.unsplash.com/photo-1576091160399-112ba8d25d1d?q=80&w=1600&auto=format&fit=crop" 
                alt="Medical team" 
                className="absolute inset-0 w-full h-full object-cover mix-blend-multiply opacity-80"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-slate-900/80 to-transparent" />
              <div className="absolute bottom-8 left-8 right-8 text-white">
                <p className="text-lg font-medium italic">"Reimagining the doctor-patient relationship for the modern era."</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-20 bg-slate-50">
        <div className="container mx-auto px-4 max-w-6xl">
          <h2 className="text-3xl font-bold text-center text-slate-900 mb-16">Our Core Values</h2>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100">
              <Shield className="h-10 w-10 text-primary mb-6" />
              <h3 className="text-xl font-bold text-slate-900 mb-3">Clinical Excellence</h3>
              <p className="text-slate-600">Every doctor on our platform goes through a rigorous 4-step verification process. We don't compromise on medical quality.</p>
            </div>
            <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100">
              <Clock className="h-10 w-10 text-primary mb-6" />
              <h3 className="text-xl font-bold text-slate-900 mb-3">Urgency & Respect</h3>
              <p className="text-slate-600">Your time matters. When you're sick, minutes feel like hours. We optimize our entire logistics network for speed and punctuality.</p>
            </div>
            <div className="bg-white p-8 rounded-2xl shadow-sm border border-slate-100">
              <Heart className="h-10 w-10 text-primary mb-6" />
              <h3 className="text-xl font-bold text-slate-900 mb-3">Compassionate Care</h3>
              <p className="text-slate-600">Technology is just the enabler. At the core, healthcare is human. We hire doctors who are not just skilled, but genuinely empathetic.</p>
            </div>
          </div>
        </div>
      </section>

      {/* Leadership Team Placeholder */}
      <section className="py-20">
        <div className="container mx-auto px-4 max-w-5xl">
          <h2 className="text-3xl font-bold text-center text-slate-900 mb-16">Leadership Team</h2>
          <div className="grid md:grid-cols-4 gap-6">
            {[
              { name: "Dr. Sarah Chen", role: "Chief Medical Officer", img: "1" },
              { name: "Marcus Johnson", role: "CEO & Founder", img: "2" },
              { name: "Priya Patel", role: "Head of Operations", img: "3" },
              { name: "David Kim", role: "Chief Technology Officer", img: "4" }
            ].map((person, i) => (
              <div key={i} className="text-center group">
                <div className="w-32 h-32 mx-auto rounded-full overflow-hidden mb-4 border-4 border-slate-50 group-hover:border-primary/20 transition-colors">
                  <img src={`https://api.dicebear.com/7.x/notionists/svg?seed=${person.img}&backgroundColor=f1f5f9`} alt={person.name} className="w-full h-full object-cover" />
                </div>
                <h4 className="font-bold text-slate-900 text-lg">{person.name}</h4>
                <p className="text-primary font-medium text-sm">{person.role}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
