import { Link } from "wouter";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/button";
import { PhoneCall, Calendar, Activity, Clock, ShieldCheck, HeartPulse, Video, Home as HomeIcon, Star } from "lucide-react";
import { useGetPlatformStats, useListSpecialties, useGetFeaturedDoctors, useGetFeaturedReviews } from "@workspace/api-client-react";
import { Skeleton } from "@/components/ui/skeleton";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

export default function Home() {
  const { data: stats } = useGetPlatformStats();
  const { data: specialties, isLoading: loadingSpecialties } = useListSpecialties();
  const { data: featuredDoctors, isLoading: loadingDoctors } = useGetFeaturedDoctors();
  const { data: reviews, isLoading: loadingReviews } = useGetFeaturedReviews();

  return (
    <div className="flex flex-col min-h-screen">
      {/* Hero Section */}
      <section className="relative overflow-hidden bg-gradient-to-br from-primary/5 via-background to-secondary/20 pt-20 pb-32">
        <div className="absolute inset-0 bg-[url('https://grainy-gradients.vercel.app/noise.svg')] opacity-20 mix-blend-overlay pointer-events-none"></div>
        <div className="container mx-auto px-4 md:px-6 relative z-10">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <motion.div 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6 }}
              className="max-w-2xl"
            >
              <Badge variant="secondary" className="mb-6 px-3 py-1 text-sm bg-primary/10 text-primary border-primary/20 hover:bg-primary/20">
                <HeartPulse className="w-4 h-4 mr-2" />
                Premium On-Demand Healthcare
              </Badge>
              <h1 className="text-5xl md:text-6xl font-extrabold tracking-tight text-slate-900 mb-6 leading-[1.1]">
                Find Trusted Doctors at Your <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-accent">Doorstep</span> in Minutes
              </h1>
              <p className="text-lg md:text-xl text-slate-600 mb-8 leading-relaxed max-w-xl">
                Experience healthcare that comes to you. Book home visits, emergency care, or video consultations with verified top-tier specialists instantly.
              </p>
              
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" className="h-14 px-8 text-base shadow-lg shadow-primary/20" asChild>
                  <Link href="/find-doctors">
                    <Calendar className="mr-2 h-5 w-5" />
                    Book Doctor Now
                  </Link>
                </Button>
                <Button size="lg" variant="destructive" className="h-14 px-8 text-base shadow-lg shadow-destructive/20 hover:bg-destructive/90" asChild>
                  <Link href="/emergency">
                    <PhoneCall className="mr-2 h-5 w-5 animate-pulse" />
                    Emergency Help
                  </Link>
                </Button>
              </div>
              
              <div className="mt-10 flex items-center gap-4 text-sm text-slate-500 font-medium">
                <div className="flex -space-x-2">
                  {[1, 2, 3, 4].map(i => (
                    <div key={i} className="w-8 h-8 rounded-full bg-slate-200 border-2 border-white flex items-center justify-center overflow-hidden">
                      <img src={`https://api.dicebear.com/7.x/notionists/svg?seed=${i}&backgroundColor=d1d5db`} alt="User" />
                    </div>
                  ))}
                </div>
                <span>Trusted by 10,000+ patients in your city</span>
              </div>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.8, delay: 0.2 }}
              className="relative hidden lg:block"
            >
              <div className="absolute inset-0 bg-gradient-to-tr from-primary/20 to-accent/20 rounded-[3rem] blur-3xl -z-10"></div>
              <img 
                src="https://images.unsplash.com/photo-1622253692010-333f2da6031d?q=80&w=1600&auto=format&fit=crop" 
                alt="Doctor consulting with patient" 
                className="rounded-[2rem] shadow-2xl object-cover h-[600px] w-full border border-white/50"
              />
              <Card className="absolute -bottom-6 -left-6 p-4 shadow-xl border-white/60 bg-white/90 backdrop-blur">
                <CardContent className="p-0 flex items-center gap-4">
                  <div className="bg-emerald-100 p-3 rounded-full text-emerald-600">
                    <Clock className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-slate-900">Average Wait Time</p>
                    <p className="text-xl font-bold text-emerald-600">&lt; 30 Mins</p>
                  </div>
                </CardContent>
              </Card>
              <Card className="absolute top-12 -right-8 p-4 shadow-xl border-white/60 bg-white/90 backdrop-blur">
                <CardContent className="p-0 flex items-center gap-4">
                  <div className="bg-primary/10 p-3 rounded-full text-primary">
                    <ShieldCheck className="w-6 h-6" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-slate-900">Verified Doctors</p>
                    <p className="text-lg font-bold text-primary">100% Certified</p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white border-y">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            <div className="text-center space-y-2">
              <h3 className="text-4xl font-extrabold text-primary">{stats?.totalPatients ? `${(stats.totalPatients / 1000).toFixed(1)}k+` : "10k+"}</h3>
              <p className="text-sm font-medium text-slate-500 uppercase tracking-wider">Patients Served</p>
            </div>
            <div className="text-center space-y-2">
              <h3 className="text-4xl font-extrabold text-primary">{stats?.totalDoctors ? `${(stats.totalDoctors / 1000).toFixed(1)}k+` : "2k+"}</h3>
              <p className="text-sm font-medium text-slate-500 uppercase tracking-wider">Verified Doctors</p>
            </div>
            <div className="text-center space-y-2">
              <h3 className="text-4xl font-extrabold text-primary">{stats?.totalCities || "50"}+</h3>
              <p className="text-sm font-medium text-slate-500 uppercase tracking-wider">Cities Covered</p>
            </div>
            <div className="text-center space-y-2">
              <h3 className="text-4xl font-extrabold text-emerald-500">{stats?.satisfactionRate || 98}%</h3>
              <p className="text-sm font-medium text-slate-500 uppercase tracking-wider">Satisfaction Rate</p>
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-24 bg-slate-50">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-slate-900 mb-4">How Can We Help You Today?</h2>
            <p className="text-lg text-slate-600">Choose the type of care that best fits your immediate needs.</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <Card className="hover:shadow-xl transition-all duration-300 border-transparent hover:border-primary/20 group cursor-pointer">
              <CardContent className="p-8 text-center space-y-6">
                <div className="w-16 h-16 mx-auto bg-primary/10 rounded-2xl flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-white transition-colors">
                  <HomeIcon className="w-8 h-8" />
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2 text-slate-900">Home Visit</h3>
                  <p className="text-slate-600 mb-6">A qualified doctor will arrive at your doorstep within 60 minutes for comprehensive in-person care.</p>
                  <Button variant="outline" className="w-full group-hover:bg-primary group-hover:text-white transition-colors" asChild>
                    <Link href="/book?type=home_visit">Book Home Visit</Link>
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card className="hover:shadow-xl transition-all duration-300 border-transparent hover:border-primary/20 group cursor-pointer relative overflow-hidden">
              <div className="absolute top-0 right-0 bg-accent text-white text-xs font-bold px-3 py-1 rounded-bl-lg">Popular</div>
              <CardContent className="p-8 text-center space-y-6">
                <div className="w-16 h-16 mx-auto bg-primary/10 rounded-2xl flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-white transition-colors">
                  <Video className="w-8 h-8" />
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2 text-slate-900">Video Consult</h3>
                  <p className="text-slate-600 mb-6">Connect instantly with a specialist via secure video call. Prescriptions sent directly to your phone.</p>
                  <Button variant="outline" className="w-full group-hover:bg-primary group-hover:text-white transition-colors" asChild>
                    <Link href="/book?type=video_consultation">Start Video Call</Link>
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card className="hover:shadow-xl transition-all duration-300 border-transparent hover:border-destructive/30 group cursor-pointer">
              <CardContent className="p-8 text-center space-y-6">
                <div className="w-16 h-16 mx-auto bg-destructive/10 rounded-2xl flex items-center justify-center text-destructive group-hover:bg-destructive group-hover:text-white transition-colors">
                  <Activity className="w-8 h-8" />
                </div>
                <div>
                  <h3 className="text-xl font-bold mb-2 text-slate-900">Emergency</h3>
                  <p className="text-slate-600 mb-6">Immediate medical attention for urgent non-life-threatening conditions. Priority dispatch.</p>
                  <Button variant="destructive" className="w-full" asChild>
                    <Link href="/emergency">Request Emergency</Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Explore Specialties */}
      <section className="py-24 bg-white">
        <div className="container mx-auto px-4">
          <div className="flex flex-col sm:flex-row justify-between items-end mb-12 gap-4">
            <div>
              <h2 className="text-3xl font-bold text-slate-900 mb-2">Explore Specialties</h2>
              <p className="text-slate-600">Find the right specialist for your specific health needs.</p>
            </div>
            <Button variant="ghost" asChild>
              <Link href="/find-doctors">View All Specialists</Link>
            </Button>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {loadingSpecialties ? (
              Array(6).fill(0).map((_, i) => <Skeleton key={i} className="h-32 rounded-xl" />)
            ) : specialties?.slice(0, 6).map((spec) => (
              <Link key={spec.id} href={`/find-doctors?specialty=${spec.id}`}>
                <Card className="h-full hover:border-primary/50 hover:shadow-md transition-all cursor-pointer text-center group">
                  <CardContent className="p-6 flex flex-col items-center justify-center gap-3">
                    <div className="p-3 bg-slate-50 rounded-full group-hover:bg-primary/10 group-hover:text-primary transition-colors">
                      <span className="text-2xl font-serif text-primary/80 group-hover:text-primary">{spec.icon}</span>
                    </div>
                    <div>
                      <h4 className="font-medium text-slate-900 text-sm">{spec.name}</h4>
                      <p className="text-xs text-slate-500 mt-1">{spec.doctorCount} Doctors</p>
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-24 bg-slate-900 text-white">
        <div className="container mx-auto px-4">
          <div className="text-center max-w-2xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">Patient Stories</h2>
            <p className="text-slate-400">Hear what our patients have to say about their MedDoor experience.</p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {loadingReviews ? (
              Array(3).fill(0).map((_, i) => <Skeleton key={i} className="h-48 rounded-xl bg-slate-800" />)
            ) : reviews?.slice(0, 3).map((review) => (
              <Card key={review.id} className="bg-slate-800 border-slate-700 text-white">
                <CardContent className="p-6 space-y-4">
                  <div className="flex text-amber-400">
                    {Array.from({ length: 5 }).map((_, i) => (
                      <Star key={i} className={`h-5 w-5 ${i < review.rating ? "fill-current" : "text-slate-600"}`} />
                    ))}
                  </div>
                  <p className="text-slate-300 italic leading-relaxed">"{review.comment}"</p>
                  <div>
                    <p className="font-bold">{review.patientName}</p>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
