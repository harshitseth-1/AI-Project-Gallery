import { useState } from "react";
import { Link } from "wouter";
import { useListAppointments, useUpdateAppointment } from "@workspace/api-client-react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";
import { Calendar, Clock, MapPin, Video, User, AlertCircle, Loader2, IndianRupee } from "lucide-react";
import { format, isPast, parseISO } from "date-fns";

export default function Appointments() {
  const { toast } = useToast();
  const [cancelingId, setCancelingId] = useState<number | null>(null);
  
  // Hardcoded patient ID 1 for demonstration
  const { data: appointments, isLoading, refetch } = useListAppointments({ patientId: 1 });
  const updateAppointment = useUpdateAppointment();

  const handleCancel = async (id: number) => {
    setCancelingId(id);
    try {
      await updateAppointment.mutateAsync({
        id,
        data: { status: 'cancelled' }
      });
      toast({
        title: "Appointment Cancelled",
        description: "Your appointment has been successfully cancelled."
      });
      refetch();
    } catch (error) {
      toast({
        title: "Action Failed",
        description: "Could not cancel appointment. Please try again or contact support.",
        variant: "destructive"
      });
    } finally {
      setCancelingId(null);
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'confirmed': return <Badge className="bg-emerald-500">Confirmed</Badge>;
      case 'pending': return <Badge variant="secondary" className="bg-amber-100 text-amber-800">Pending</Badge>;
      case 'completed': return <Badge variant="outline" className="text-slate-500">Completed</Badge>;
      case 'cancelled': return <Badge variant="destructive">Cancelled</Badge>;
      default: return <Badge variant="secondary">{status}</Badge>;
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'home_visit': return <User className="h-4 w-4" />;
      case 'video_consultation': return <Video className="h-4 w-4" />;
      case 'emergency': return <AlertCircle className="h-4 w-4 text-destructive" />;
      default: return <Calendar className="h-4 w-4" />;
    }
  };

  const upcoming = appointments?.filter(a => a.status === 'confirmed' || a.status === 'pending') || [];
  const past = appointments?.filter(a => a.status === 'completed' || a.status === 'cancelled') || [];

  const AppointmentList = ({ items }: { items: typeof appointments }) => {
    if (isLoading) {
      return (
        <div className="space-y-4">
          {[1, 2].map(i => (
            <Card key={i} className="overflow-hidden">
              <CardContent className="p-0"><Skeleton className="h-48 w-full" /></CardContent>
            </Card>
          ))}
        </div>
      );
    }

    if (!items || items.length === 0) {
      return (
        <div className="bg-white rounded-xl border border-dashed p-12 text-center flex flex-col items-center">
          <div className="w-16 h-16 bg-slate-50 rounded-full flex items-center justify-center mb-4">
            <Calendar className="w-8 h-8 text-slate-400" />
          </div>
          <h3 className="text-lg font-bold text-slate-900 mb-2">No appointments found</h3>
          <p className="text-slate-500 mb-6 max-w-sm">You don't have any appointments in this category.</p>
          <Button asChild><Link href="/find-doctors">Book an Appointment</Link></Button>
        </div>
      );
    }

    return (
      <div className="space-y-4">
        {items.map((apt) => (
          <Card key={apt.id} className="overflow-hidden border-slate-200 shadow-sm transition-all hover:shadow-md">
            <div className={`h-1.5 w-full ${apt.type === 'emergency' ? 'bg-destructive' : 'bg-primary'}`} />
            <CardHeader className="bg-slate-50 border-b p-4 sm:px-6 flex flex-row items-center justify-between gap-4 space-y-0">
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-lg ${apt.type === 'emergency' ? 'bg-destructive/10 text-destructive' : 'bg-primary/10 text-primary'}`}>
                  {getTypeIcon(apt.type)}
                </div>
                <div>
                  <CardTitle className="text-base sm:text-lg">{apt.type.split('_').map(w => w.charAt(0).toUpperCase() + w.slice(1)).join(' ')}</CardTitle>
                  <CardDescription>ID: #{apt.id.toString().padStart(6, '0')}</CardDescription>
                </div>
              </div>
              <div>{getStatusBadge(apt.status)}</div>
            </CardHeader>
            <CardContent className="p-4 sm:px-6 py-6 grid sm:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <p className="text-sm font-medium text-slate-500 mb-1">Doctor</p>
                  <div className="flex items-center gap-2">
                    <User className="h-4 w-4 text-slate-400" />
                    <span className="font-semibold text-slate-900">{apt.doctorName}</span>
                    <span className="text-sm text-slate-500">({apt.specialty})</span>
                  </div>
                </div>
                
                <div>
                  <p className="text-sm font-medium text-slate-500 mb-1">Schedule</p>
                  <div className="flex items-center gap-4">
                    <div className="flex items-center gap-1.5 font-medium text-slate-900">
                      <Calendar className="h-4 w-4 text-primary" />
                      {format(new Date(apt.date), 'MMM d, yyyy')}
                    </div>
                    <div className="flex items-center gap-1.5 font-medium text-slate-900">
                      <Clock className="h-4 w-4 text-primary" />
                      {apt.time}
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="space-y-4">
                {apt.address && (
                  <div>
                    <p className="text-sm font-medium text-slate-500 mb-1">Location</p>
                    <div className="flex items-start gap-2">
                      <MapPin className="h-4 w-4 text-slate-400 shrink-0 mt-0.5" />
                      <span className="text-sm text-slate-900 line-clamp-2">{apt.address}</span>
                    </div>
                  </div>
                )}
                
                <div>
                  <p className="text-sm font-medium text-slate-500 mb-1">Consultation Fee</p>
                  <div className="flex items-center gap-1.5 font-semibold text-slate-900">
                    <IndianRupee className="h-4 w-4 text-slate-400" />
                    {apt.fee}
                  </div>
                </div>
              </div>
            </CardContent>
            
            {(apt.status === 'confirmed' || apt.status === 'pending') && (
              <CardFooter className="bg-slate-50 border-t p-4 sm:px-6 flex justify-end gap-3">
                {apt.type === 'video_consultation' && apt.status === 'confirmed' && (
                  <Button className="bg-indigo-600 hover:bg-indigo-700">
                    <Video className="mr-2 h-4 w-4" /> Join Call
                  </Button>
                )}
                <Button 
                  variant="outline" 
                  className="text-destructive hover:bg-destructive/5 hover:text-destructive border-destructive/20"
                  onClick={() => handleCancel(apt.id)}
                  disabled={cancelingId === apt.id}
                >
                  {cancelingId === apt.id ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : null}
                  Cancel Appointment
                </Button>
              </CardFooter>
            )}
          </Card>
        ))}
      </div>
    );
  };

  return (
    <div className="container mx-auto px-4 py-8 max-w-4xl min-h-[calc(100vh-4rem)]">
      <div className="mb-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">My Appointments</h1>
          <p className="text-slate-600 mt-1">Manage your upcoming and past consultations.</p>
        </div>
        <Button asChild>
          <Link href="/find-doctors">Book New Appointment</Link>
        </Button>
      </div>

      <Tabs defaultValue="upcoming" className="w-full">
        <TabsList className="grid w-full grid-cols-2 mb-8 h-12 bg-slate-100/50 p-1">
          <TabsTrigger value="upcoming" className="rounded-md data-[state=active]:bg-white data-[state=active]:shadow-sm">
            Upcoming ({upcoming.length})
          </TabsTrigger>
          <TabsTrigger value="past" className="rounded-md data-[state=active]:bg-white data-[state=active]:shadow-sm">
            Past History ({past.length})
          </TabsTrigger>
        </TabsList>
        <TabsContent value="upcoming" className="mt-0">
          <AppointmentList items={upcoming} />
        </TabsContent>
        <TabsContent value="past" className="mt-0">
          <AppointmentList items={past} />
        </TabsContent>
      </Tabs>
    </div>
  );
}
