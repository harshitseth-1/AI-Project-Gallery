import { useParams } from "wouter";
import { 
  useGetDoctor, 
  useGetDoctorAvailability, 
  useListReviews,
  getGetDoctorQueryKey,
  getGetDoctorAvailabilityQueryKey,
  getListReviewsQueryKey
} from "@workspace/api-client-react";
import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Star, MapPin, Briefcase, GraduationCap, Languages, IndianRupee, Clock, Calendar, CheckCircle2 } from "lucide-react";
import { format } from "date-fns";

export default function DoctorProfile() {
  const params = useParams();
  const id = parseInt(params.id || "0");

  const { data: doctor, isLoading: loadingDoctor } = useGetDoctor(id, {
    query: { enabled: !!id, queryKey: getGetDoctorQueryKey(id) }
  });

  const { data: slots, isLoading: loadingSlots } = useGetDoctorAvailability(id, {
    query: { enabled: !!id, queryKey: getGetDoctorAvailabilityQueryKey(id) }
  });

  const { data: reviews, isLoading: loadingReviews } = useListReviews({ doctorId: id }, {
    query: { enabled: !!id, queryKey: getListReviewsQueryKey({ doctorId: id }) }
  });

  if (loadingDoctor) {
    return (
      <div className="container mx-auto px-4 py-8 max-w-5xl">
        <Skeleton className="h-64 w-full rounded-2xl mb-8" />
        <div className="grid md:grid-cols-3 gap-8">
          <div className="md:col-span-2 space-y-6">
            <Skeleton className="h-40 rounded-xl" />
            <Skeleton className="h-40 rounded-xl" />
          </div>
          <Skeleton className="h-80 rounded-xl" />
        </div>
      </div>
    );
  }

  if (!doctor) {
    return (
      <div className="container mx-auto px-4 py-20 text-center">
        <h2 className="text-2xl font-bold text-slate-900 mb-2">Doctor not found</h2>
        <p className="text-slate-500 mb-6">The profile you are looking for does not exist or has been removed.</p>
        <Button asChild><Link href="/find-doctors">Back to Search</Link></Button>
      </div>
    );
  }

  const upcomingSlots = slots?.filter(s => !s.isBooked).slice(0, 5) || [];

  return (
    <div className="bg-slate-50 min-h-[calc(100vh-4rem)] pb-12">
      {/* Header Profile Section */}
      <div className="bg-white border-b">
        <div className="container mx-auto px-4 py-8 max-w-5xl">
          <div className="flex flex-col md:flex-row gap-6 md:items-start">
            <Avatar className="h-32 w-32 border-4 border-white shadow-lg shrink-0">
              <AvatarImage src={doctor.photoUrl || undefined} alt={doctor.name} />
              <AvatarFallback className="text-3xl bg-primary/10 text-primary">
                {doctor.name.split(" ").map(n => n[0]).join("").substring(0, 2)}
              </AvatarFallback>
            </Avatar>

            <div className="flex-1 space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <h1 className="text-3xl font-bold text-slate-900">{doctor.name}</h1>
                    {doctor.isVerified && (
                      <CheckCircle2 className="h-6 w-6 text-emerald-500 fill-emerald-50" />
                    )}
                  </div>
                  <p className="text-lg font-medium text-primary">{doctor.specialty}</p>
                </div>
                
                <div className="flex gap-3">
                  <Button asChild size="lg" className="shadow-md">
                    <Link href={`/book?doctorId=${doctor.id}`}>Book Appointment</Link>
                  </Button>
                </div>
              </div>

              <div className="flex flex-wrap items-center gap-x-6 gap-y-2 text-sm text-slate-600">
                <div className="flex items-center gap-1.5">
                  <div className="flex items-center text-amber-500">
                    <Star className="h-4 w-4 fill-current" />
                    <span className="ml-1 font-bold text-slate-900">{doctor.rating.toFixed(1)}</span>
                  </div>
                  <span>({doctor.reviewCount} Reviews)</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <Briefcase className="h-4 w-4 text-slate-400" />
                  <span>{doctor.experience} Years Exp.</span>
                </div>
                <div className="flex items-center gap-1.5">
                  <MapPin className="h-4 w-4 text-slate-400" />
                  <span>{doctor.city}</span>
                </div>
                <div className="flex items-center gap-1.5 font-medium text-slate-900 bg-slate-100 px-2 py-1 rounded-md">
                  <IndianRupee className="h-4 w-4 text-slate-500" />
                  <span>{doctor.fee} / consultation</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8 max-w-5xl">
        <div className="grid md:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="md:col-span-2 space-y-6">
            <Tabs defaultValue="about" className="w-full">
              <TabsList className="w-full justify-start border-b rounded-none h-auto p-0 bg-transparent mb-6">
                <TabsTrigger value="about" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:shadow-none px-6 py-3">About</TabsTrigger>
                <TabsTrigger value="reviews" className="rounded-none border-b-2 border-transparent data-[state=active]:border-primary data-[state=active]:bg-transparent data-[state=active]:shadow-none px-6 py-3">Reviews ({doctor.reviewCount})</TabsTrigger>
              </TabsList>
              
              <TabsContent value="about" className="space-y-8 animate-in fade-in-50">
                <div className="bg-white p-6 rounded-xl border shadow-sm space-y-4">
                  <h3 className="text-lg font-bold text-slate-900">About Doctor</h3>
                  <p className="text-slate-600 leading-relaxed whitespace-pre-wrap">
                    {doctor.bio || "No biography provided."}
                  </p>
                </div>

                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="bg-white p-6 rounded-xl border shadow-sm space-y-4">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="p-2 bg-primary/10 rounded-lg text-primary">
                        <GraduationCap className="h-5 w-5" />
                      </div>
                      <h3 className="text-lg font-bold text-slate-900">Qualifications</h3>
                    </div>
                    <ul className="space-y-2">
                      {doctor.qualifications?.map((q, i) => (
                        <li key={i} className="flex items-start gap-2 text-slate-600">
                          <span className="mt-1.5 h-1.5 w-1.5 rounded-full bg-slate-400 shrink-0"></span>
                          <span>{q}</span>
                        </li>
                      )) || <li className="text-slate-500">Not specified</li>}
                    </ul>
                  </div>

                  <div className="bg-white p-6 rounded-xl border shadow-sm space-y-4">
                    <div className="flex items-center gap-2 mb-2">
                      <div className="p-2 bg-secondary rounded-lg text-secondary-foreground">
                        <Languages className="h-5 w-5" />
                      </div>
                      <h3 className="text-lg font-bold text-slate-900">Languages</h3>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {doctor.languages?.map((lang, i) => (
                        <Badge key={i} variant="outline" className="bg-slate-50">{lang}</Badge>
                      )) || <span className="text-slate-500">Not specified</span>}
                    </div>
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="reviews" className="space-y-4 animate-in fade-in-50">
                {loadingReviews ? (
                  <Skeleton className="h-32 w-full rounded-xl" />
                ) : reviews && reviews.length > 0 ? (
                  <div className="space-y-4">
                    {reviews.map(review => (
                      <div key={review.id} className="bg-white p-6 rounded-xl border shadow-sm">
                        <div className="flex justify-between items-start mb-3">
                          <div>
                            <p className="font-semibold text-slate-900">{review.patientName}</p>
                            <p className="text-xs text-slate-500">{format(new Date(review.createdAt), 'MMM d, yyyy')}</p>
                          </div>
                          <div className="flex text-amber-500">
                            {Array.from({ length: 5 }).map((_, i) => (
                              <Star key={i} className={`h-4 w-4 ${i < review.rating ? 'fill-current' : 'text-slate-200'}`} />
                            ))}
                          </div>
                        </div>
                        <p className="text-slate-600 italic">"{review.comment}"</p>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="bg-white p-12 text-center rounded-xl border shadow-sm">
                    <Star className="h-12 w-12 text-slate-200 mx-auto mb-3" />
                    <h3 className="text-lg font-medium text-slate-900 mb-1">No reviews yet</h3>
                    <p className="text-slate-500">Be the first to review this doctor after an appointment.</p>
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </div>

          {/* Sidebar - Availability */}
          <div className="space-y-6">
            <div className="bg-white p-6 rounded-xl border shadow-sm sticky top-24">
              <div className="flex items-center justify-between mb-4 pb-4 border-b">
                <h3 className="text-lg font-bold text-slate-900">Next Available</h3>
                {doctor.isAvailable ? (
                  <Badge className="bg-emerald-500">Available</Badge>
                ) : (
                  <Badge variant="secondary">Unavailable</Badge>
                )}
              </div>

              {loadingSlots ? (
                <div className="space-y-3">
                  <Skeleton className="h-10 w-full rounded-md" />
                  <Skeleton className="h-10 w-full rounded-md" />
                  <Skeleton className="h-10 w-full rounded-md" />
                </div>
              ) : upcomingSlots.length > 0 ? (
                <div className="space-y-4">
                  <div className="space-y-2">
                    {upcomingSlots.map(slot => (
                      <div key={slot.id} className="flex items-center justify-between p-3 rounded-lg border border-slate-100 bg-slate-50">
                        <div className="flex items-center gap-3">
                          <div className="bg-white p-2 rounded-md shadow-sm border border-slate-100 text-primary">
                            <Calendar className="h-4 w-4" />
                          </div>
                          <div>
                            <p className="text-sm font-medium text-slate-900">{format(new Date(slot.date), 'MMM d, yyyy')}</p>
                            <div className="flex items-center text-xs text-slate-500 gap-1 mt-0.5">
                              <Clock className="h-3 w-3" />
                              <span>{slot.startTime} - {slot.endTime}</span>
                            </div>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                  <Button className="w-full" asChild>
                    <Link href={`/book?doctorId=${doctor.id}&date=${upcomingSlots[0].date}`}>Book Time Slot</Link>
                  </Button>
                </div>
              ) : (
                <div className="text-center py-6">
                  <Calendar className="h-10 w-10 text-slate-300 mx-auto mb-3" />
                  <p className="text-sm text-slate-600 font-medium">No slots available</p>
                  <p className="text-xs text-slate-500 mt-1">Please check back later or call the clinic.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
