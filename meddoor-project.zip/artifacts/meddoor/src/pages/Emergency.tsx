import { useState } from "react";
import { useLocation } from "wouter";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useCreateEmergencyRequest } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { Loader2, PhoneCall, AlertCircle, MapPin, User } from "lucide-react";

const emergencySchema = z.object({
  patientName: z.string().min(2, "Name is required"),
  phone: z.string().min(10, "Valid phone number is required"),
  address: z.string().min(5, "Complete address is required for dispatch"),
  description: z.string().min(10, "Please describe the emergency")
});

type EmergencyFormValues = z.infer<typeof emergencySchema>;

export default function Emergency() {
  const [_, setLocation] = useLocation();
  const { toast } = useToast();
  const [isSuccess, setIsSuccess] = useState(false);
  
  const createEmergency = useCreateEmergencyRequest();

  const form = useForm<EmergencyFormValues>({
    resolver: zodResolver(emergencySchema),
    defaultValues: {
      patientName: "",
      phone: "",
      address: "",
      description: ""
    }
  });

  async function onSubmit(data: EmergencyFormValues) {
    try {
      await createEmergency.mutateAsync({ data });
      setIsSuccess(true);
      window.scrollTo(0, 0);
    } catch (error) {
      toast({
        title: "Request Failed",
        description: "Could not process request. Please call 911 immediately.",
        variant: "destructive"
      });
    }
  }

  if (isSuccess) {
    return (
      <div className="min-h-[calc(100vh-4rem)] bg-destructive/5 flex items-center justify-center py-12 px-4">
        <div className="bg-white p-8 md:p-12 rounded-3xl shadow-xl border border-destructive/20 max-w-lg w-full text-center relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-2 bg-destructive animate-pulse" />
          
          <div className="w-20 h-20 bg-destructive/10 rounded-full flex items-center justify-center mx-auto mb-6">
            <AlertCircle className="w-10 h-10 text-destructive" />
          </div>
          
          <h1 className="text-3xl font-bold text-slate-900 mb-4">Help is on the way</h1>
          <p className="text-lg text-slate-600 mb-8">
            Your emergency request has been received. A doctor has been dispatched and should arrive in approximately:
          </p>
          
          <div className="text-5xl font-extrabold text-destructive mb-8">
            12-15 <span className="text-2xl font-bold">mins</span>
          </div>

          <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 text-amber-800 text-sm text-left mb-8">
            <p className="font-semibold mb-1">While you wait:</p>
            <ul className="list-disc pl-5 space-y-1">
              <li>Ensure the entrance is accessible</li>
              <li>Keep the patient calm and comfortable</li>
              <li>Gather any current medications</li>
              <li>If the situation worsens, call emergency services immediately</li>
            </ul>
          </div>

          <Button variant="outline" className="w-full" onClick={() => setLocation("/")}>
            Return to Homepage
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-[calc(100vh-4rem)] bg-slate-50 py-12">
      <div className="container mx-auto px-4 max-w-2xl">
        <div className="text-center mb-10">
          <div className="inline-flex items-center justify-center p-4 bg-destructive/10 rounded-full mb-4">
            <PhoneCall className="h-10 w-10 text-destructive animate-pulse" />
          </div>
          <h1 className="text-4xl font-bold text-slate-900 mb-3 tracking-tight">Emergency Doctor Request</h1>
          <p className="text-lg text-slate-600 max-w-lg mx-auto">
            Get immediate medical attention at your location. Priority dispatch for urgent, non-life-threatening conditions.
          </p>
        </div>

        <Card className="border-destructive/20 shadow-xl overflow-hidden relative">
          <div className="absolute top-0 left-0 w-full h-1 bg-destructive" />
          <CardHeader className="bg-destructive/5 pb-8 border-b border-destructive/10">
            <CardTitle className="text-destructive flex items-center gap-2">
              <AlertCircle className="w-5 h-5" />
              Disclaimer
            </CardTitle>
            <CardDescription className="text-slate-700 font-medium">
              If this is a life-threatening medical emergency (heart attack, severe bleeding, stroke), please call 911 or your local emergency services immediately.
            </CardDescription>
          </CardHeader>

          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)}>
              <CardContent className="p-6 md:p-8 space-y-6">
                <div className="grid sm:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="patientName"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Patient Name</FormLabel>
                        <FormControl>
                          <div className="relative">
                            <User className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                            <Input placeholder="Full name" className="pl-10 bg-slate-50" {...field} />
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                  <FormField
                    control={form.control}
                    name="phone"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Contact Number</FormLabel>
                        <FormControl>
                          <div className="relative">
                            <PhoneCall className="absolute left-3 top-2.5 h-4 w-4 text-slate-400" />
                            <Input type="tel" placeholder="Phone number" className="pl-10 bg-slate-50" {...field} />
                          </div>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                <FormField
                  control={form.control}
                  name="address"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Exact Location for Dispatch</FormLabel>
                      <FormControl>
                        <div className="relative">
                          <MapPin className="absolute left-3 top-3 h-4 w-4 text-slate-400" />
                          <Textarea 
                            placeholder="Complete address including apartment number and landmarks..." 
                            className="pl-10 min-h-[100px] bg-slate-50 resize-none" 
                            {...field} 
                          />
                        </div>
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="description"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Nature of Emergency</FormLabel>
                      <FormControl>
                        <Textarea 
                          placeholder="Briefly describe the symptoms and current condition..." 
                          className="min-h-[100px] bg-slate-50 resize-none border-destructive/20 focus-visible:ring-destructive" 
                          {...field} 
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </CardContent>

              <div className="p-6 md:p-8 bg-slate-50 border-t flex flex-col sm:flex-row justify-between items-center gap-4">
                <p className="text-sm text-slate-500 font-medium">Standard emergency call-out fee applies.</p>
                <Button 
                  type="submit" 
                  size="lg" 
                  variant="destructive" 
                  className="w-full sm:w-auto px-10 h-14 text-lg shadow-lg shadow-destructive/20"
                  disabled={createEmergency.isPending}
                >
                  {createEmergency.isPending ? (
                    <>
                      <Loader2 className="mr-2 h-5 w-5 animate-spin" />
                      Dispatching...
                    </>
                  ) : (
                    "Request Doctor NOW"
                  )}
                </Button>
              </div>
            </form>
          </Form>
        </Card>
      </div>
    </div>
  );
}
