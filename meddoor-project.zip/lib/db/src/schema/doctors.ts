import { pgTable, serial, text, integer, boolean, real, json } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const doctorsTable = pgTable("doctors", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  specialty: text("specialty").notNull(),
  specialtyId: integer("specialty_id").notNull(),
  photoUrl: text("photo_url"),
  rating: real("rating").notNull().default(4.5),
  reviewCount: integer("review_count").notNull().default(0),
  experience: integer("experience").notNull(),
  city: text("city").notNull(),
  fee: real("fee").notNull(),
  bio: text("bio"),
  isAvailable: boolean("is_available").notNull().default(true),
  isVerified: boolean("is_verified").notNull().default(false),
  languages: json("languages").$type<string[]>().notNull().default([]),
  qualifications: json("qualifications").$type<string[]>().notNull().default([]),
});

export const insertDoctorSchema = createInsertSchema(doctorsTable).omit({ id: true });
export type InsertDoctor = z.infer<typeof insertDoctorSchema>;
export type Doctor = typeof doctorsTable.$inferSelect;
