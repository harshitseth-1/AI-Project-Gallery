import { pgTable, serial, text, integer, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const emergencyRequestsTable = pgTable("emergency_requests", {
  id: serial("id").primaryKey(),
  patientName: text("patient_name").notNull(),
  phone: text("phone").notNull(),
  address: text("address").notNull(),
  description: text("description").notNull(),
  status: text("status").notNull().default("pending"), // pending | dispatched | resolved
  assignedDoctorId: integer("assigned_doctor_id"),
  assignedDoctorName: text("assigned_doctor_name"),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

export const insertEmergencyRequestSchema = createInsertSchema(emergencyRequestsTable).omit({ id: true, createdAt: true });
export type InsertEmergencyRequest = z.infer<typeof insertEmergencyRequestSchema>;
export type EmergencyRequest = typeof emergencyRequestsTable.$inferSelect;
